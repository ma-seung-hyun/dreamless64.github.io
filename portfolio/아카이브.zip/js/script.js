(function($){
$(document).ready(function(){
// code start!!

// selecting
var $win = $(window),
    $h1 = $('h1');

// intro
var h1Pos = function(){
    $h1.stop().animate({
        'top': $win.height()/2 - $h1.outerHeight()/2,
        'left': $win.width()/2 - $h1.outerWidth()/2
    });
};
var introHover = function(){
  var $imgbox = $('.intro_imgbox'),
      $left = $('.intro_imgbox-leftbox'),
      $right = $('.intro_imgbox-rightbox'),
      $leftVi = $('.intro_imgbox-leftbox-v_img'),
      $leftWi = $('.intro_imgbox-leftbox-white_img'),
      $leftCi = $('.intro_imgbox-leftbox-code_img'),
      $rightVi = $('.intro_imgbox-rightbox-v_img');

  $imgbox.hover(function(){
    $left.on('mouseenter', function(){
      $leftVi.stop().animate({
        'opacity': '0.9',
        'right': '-'+ 43+'%'
      },500,'easeInOutCubic');
      $leftWi.stop().animate({
        'opacity': '0.9',
        'left':'-'+5+'%',
        'padding-left':0
      },500,'easeInOutCubic');
      $leftCi.stop().animate({'background-position': '-50px'},500,'easeInOutCubic');
      $rightVi.stop().animate({'left':'-'+57.5 +'%'},500,'easeInOutCubic');
      $right.stop().css({'background-color':'#fe1'},500,'easeInOutCubic');
    });
    $right.on('mouseenter', function(){
      $leftVi.stop().animate({
        'right': '-'+ 53+'%',
        'opacity':1
      },500,'easeInOutCubic');
      $leftWi.stop().animate({
        'left':0,
        'padding-left': 5+'%',
        'opacity':1
      },500,'easeInOutCubic');
      $leftCi.stop().animate({'background-position': '30px'},800,'easeInOutCubic');
      $rightVi.stop().animate({'left':'-'+47.5 +'%'},500,'easeInOutCubic');
      $right.stop().css({'background-color':'#fff577'});
    });
  },function(){
    $leftVi.stop().animate({
      'right': '-'+ 48+'%',
      'opacity':1
    },500,'easeInOutCubic');
    $leftWi.stop().animate({
      'left':0,
      'padding-left':0,
      'opacity':1
    },500,'easeInOutCubic');
    $leftCi.stop().animate({'background-position': '0'},800,'easeInOutCubic');
    $rightVi.stop().animate({'left':'-'+52.5 +'%'},500,'easeInOutCubic');
    $right.stop().css({'background-color':'#fe1'});
  });
  $imgbox.trigger('mouseenter');
};

//document ready --;

var justReady = function(){
  introHover();
}
var readyAndResize = function(){
  h1Pos();
}
justReady();
$win.resize(readyAndResize);
$win.trigger('resize');
});//document ready --;
})(jQuery);
